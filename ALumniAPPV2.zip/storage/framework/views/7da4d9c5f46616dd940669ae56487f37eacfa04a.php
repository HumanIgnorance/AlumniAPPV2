

















<?php

    $atmsTheme = request()->cookie('atms-theme', 'white');
    $atmsTheme = in_array($atmsTheme, ['black', 'white']) ? $atmsTheme : 'white';
    $atmsThemeColor = $atmsTheme === 'black' ? '#0a0c12' : '#ffffff';
    $atmsStatusBarStyle = $atmsTheme === 'black' ? 'black' : 'default';
?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-theme="<?php echo e($atmsTheme === 'black' ? 'black' : ''); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
    <!-- Google Site Verification -->
    <meta name="google-site-verification" content="EoE6LVDV2xrA2R1kWgPDzyDYU4Dl98Sz5dktxhT68I0">

    <!-- CSRF -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- =======================================================
            PRIMARY SEO
    ======================================================== -->

    <title><?php echo e($seoTitle); ?></title>

    <meta name="title" content="<?php echo e($seoTitle); ?>">

    <meta name="description" content="<?php echo e($seoDescription); ?>">

    <meta name="keywords" content="<?php echo e($keywords); ?>">

    <meta name="author" content="<?php echo e($author); ?>">

    <meta name="application-name" content="<?php echo e($appName); ?> - <?php echo e($siteName); ?>">

    <!-- =======================================================
            SEARCH ENGINE
    ======================================================== -->

    <meta name="robots" content="index, follow, max-image-preview:large">

    <meta name="googlebot" content="index, follow">

    <link rel="canonical" href="<?php echo e($seoCanonical); ?>">

    <!-- =======================================================
            FAVICON
    ======================================================== -->

    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e($logo); ?>">

    <link rel="icon" type="image/png" sizes="192x192" href="<?php echo e($logo); ?>">

    <link rel="shortcut icon" href="<?php echo e($logo); ?>">

    <link rel="apple-touch-icon" href="<?php echo e($logo); ?>">

    <!-- =======================================================
            OPEN GRAPH
    ======================================================== -->

    <meta property="og:type" content="website">

    <meta property="og:site_name" content="<?php echo e($siteName); ?>">

    <meta property="og:locale" content="<?php echo e($locale); ?>">

    <meta property="og:title" content="<?php echo e($seoTitle); ?>">

    <meta property="og:description" content="<?php echo e($seoDescription); ?>">

    <meta property="og:url" content="<?php echo e($seoCanonical); ?>">

    <meta property="og:image" content="<?php echo e($logo); ?>">

    <meta property="og:image:alt" content="<?php echo e($siteName); ?> <?php echo e($appName); ?> Logo">

    <meta property="og:image:width" content="512">

    <meta property="og:image:height" content="512">

    <!-- =======================================================
            TWITTER
    ======================================================== -->

    <meta name="twitter:card" content="summary_large_image">

    <meta name="twitter:title" content="<?php echo e($seoTitle); ?>">

    <meta name="twitter:description" content="<?php echo e($seoDescription); ?>">

    <meta name="twitter:image" content="<?php echo e($logo); ?>">

    <meta name="twitter:image:alt" content="<?php echo e($siteName); ?> <?php echo e($appName); ?> Logo">

    <!-- =======================================================
            MOBILE / PWA
    ======================================================== -->

    <meta name="theme-color" content="<?php echo e($atmsThemeColor); ?>">

    <meta name="apple-mobile-web-app-capable" content="yes">

    <meta name="apple-mobile-web-app-title" content="<?php echo e($appName); ?>">

    <meta name="apple-mobile-web-app-status-bar-style" content="<?php echo e($atmsStatusBarStyle); ?>">

    <meta name="mobile-web-app-capable" content="yes">

    <link rel="manifest" href="<?php echo e(route('pwa.manifest')); ?>">

    
    <!-- =======================================================
            STRUCTURED DATA
    ======================================================== -->

    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@graph": [
            {
                "@type": "CollegeOrUniversity",
                "name": "<?php echo e($siteName); ?>",
                "url": "<?php echo e(url('/')); ?>",
                "logo": "<?php echo e($logo); ?>",
                "image": "<?php echo e($logo); ?>",
                "description": "<?php echo e($seoDescription); ?>",
                "department": {
                    "@type": "Organization",
                    "name": "Alumni Tracing Management System (<?php echo e($appName); ?>)"
                }
            },
            {
                "@type": "Organization",
                "name": "<?php echo e($siteName); ?>",
                "url": "<?php echo e(url('/')); ?>",
                "logo": {
                    "@type": "ImageObject",
                    "url": "<?php echo e($logo); ?>"
                }
            },
            {
                "@type": "WebSite",
                "name": "<?php echo e($siteName); ?>",
                "alternateName": "<?php echo e($appName); ?>",
                "url": "<?php echo e(url('/')); ?>",
                "publisher": {
                    "@type": "CollegeOrUniversity",
                    "name": "<?php echo e($siteName); ?>"
                },
                "inLanguage": "en-PH"
            }
        ]
    }
    </script>

    <?php echo $__env->yieldPushContent('schema'); ?>
    <!-- =======================================================
            CSS
    ======================================================== -->

    

    <!-- Fonts -->

    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

</head>

<body>

    <div id="app"></div>

    <!-- React (Vite) -->

    <?php echo app(\App\Support\Vite::class)('resources/js/app.js'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\AlumniAPPv2\resources\views/app.blade.php ENDPATH**/ ?>